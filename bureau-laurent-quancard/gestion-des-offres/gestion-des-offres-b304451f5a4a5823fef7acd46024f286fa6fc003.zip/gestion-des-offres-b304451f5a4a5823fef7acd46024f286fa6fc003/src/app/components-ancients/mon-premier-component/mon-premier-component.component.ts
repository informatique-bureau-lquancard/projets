import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mon-premier-component',
  templateUrl: './mon-premier-component.component.html',
  styleUrls: ['./mon-premier-component.component.scss']
})
export class MonPremierComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
