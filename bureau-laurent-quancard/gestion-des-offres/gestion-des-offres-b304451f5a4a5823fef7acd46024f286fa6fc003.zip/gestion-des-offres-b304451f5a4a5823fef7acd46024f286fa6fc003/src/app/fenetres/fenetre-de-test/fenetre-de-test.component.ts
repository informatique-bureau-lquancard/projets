import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fenetre-de-test',
  templateUrl: './fenetre-de-test.component.html',
  styleUrls: ['./fenetre-de-test.component.scss']
})
export class FenetreDeTestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
