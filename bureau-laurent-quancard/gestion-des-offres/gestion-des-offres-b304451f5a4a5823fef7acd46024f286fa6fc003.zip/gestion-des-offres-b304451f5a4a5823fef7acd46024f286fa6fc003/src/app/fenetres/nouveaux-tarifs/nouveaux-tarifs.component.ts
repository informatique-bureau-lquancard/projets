import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nouveaux-tarifs',
  templateUrl: './nouveaux-tarifs.component.html',
  styleUrls: ['./nouveaux-tarifs.component.scss']
})
export class NouveauxTarifsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
