import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-offre',
  templateUrl: './detail-offre.component.html',
  styleUrls: ['./detail-offre.component.scss']
})
export class DetailOffreComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
