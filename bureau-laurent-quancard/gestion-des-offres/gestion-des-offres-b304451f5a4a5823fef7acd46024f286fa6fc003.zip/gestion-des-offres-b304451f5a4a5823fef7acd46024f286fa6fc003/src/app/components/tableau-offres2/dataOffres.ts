import { Offre } from "src/app/models/OffreAffiche.model";

let offre1 = new Offre(1, 1, "1", 2021, "BO", 10, 5, "CBO6", "com1", false)
let offre2 = new Offre(2, 2, "2", 2021, "BO", 10, 5, "CBO6", "com1", false)
let offre3 = new Offre(3, 3, "3", 2021, "BO", 10, 5, "CBO6", "com1", false)

    export let offres:Offre[] = [
        
        offre1,
        offre2,
        offre3 
    ]

    
